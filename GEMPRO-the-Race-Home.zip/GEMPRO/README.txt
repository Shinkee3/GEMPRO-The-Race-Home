To run file, extract all files into a folder and open GEMPRO_Katigbac.exe

Enjoy